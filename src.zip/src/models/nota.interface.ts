export interface Nota {
    nombre_asignatura:string;
    puntuación:number;
}