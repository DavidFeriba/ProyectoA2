export interface Logro {
    titulo:string;
    informacion:string;
}