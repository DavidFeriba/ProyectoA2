export interface Aviso {
    titulo:string;
    informacion:string;
}