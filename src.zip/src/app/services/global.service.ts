import { Injectable } from '@angular/core';

import { Profesor } from 'src/models/profesor.interface';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  
  

  constructor() { }
}
